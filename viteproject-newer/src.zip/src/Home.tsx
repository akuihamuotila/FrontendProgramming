const Home = () => {
    return <h2>This is home page</h2>;
  };
  export default Home;