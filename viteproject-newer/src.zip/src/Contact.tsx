const Contact = () => {
    return <h2>This is contact page</h2>;
  };
  export default Contact;